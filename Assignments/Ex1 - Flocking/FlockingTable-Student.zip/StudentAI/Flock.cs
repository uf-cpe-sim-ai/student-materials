﻿using System.Collections.Generic;
using AI.SteeringBehaviors.Core;

namespace AI.SteeringBehaviors.StudentAI
{
    public class Flock
    {
        public float AlignmentStrength { get; set; }
        public float CohesionStrength { get; set; }
        public float SeparationStrength { get; set; }
        public List<MovingObject> Boids { get; protected set; }
        public Vector3 AveragePosition { get; set; }
        protected Vector3 AverageForward { get; set; }
        public float FlockRadius { get; set; }

        #region TODO
        public virtual void Update(float deltaTime)
        {
            // Update goes here

            // If using normalize methods:
            // Use the instance Normalize() that changes the vector in place rather than the static Normalize() that returns a new vector
            // This is to ensure the vector calculation tests work correctly
        }
        #endregion
    }
}
