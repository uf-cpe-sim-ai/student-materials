﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Windows.Forms;
using AI.SteeringBehaviors.Core;
using ConsoleTableExt;

namespace AI.SteeringBehaviors.ApplicationPresentation
{
    public partial class Main : Form
    {
        #region Non designer fields

        int frameCount;
        int shipCount;
        float deltaTimeAccumulator;
        float oneSecondAccumulator;
        const float UpdateTimeStep = 0.04f;
        const int sliderPrecision = 100;
        Random rng;
        List<ITaskForce> studTaskForces;
        List<ITaskForce> exTaskForces;

        #region Rendering stuff

        Graphics renderControlGraphics;
        Graphics backbufferGraphics;
        Bitmap backbuffer;
        Bitmap backgroundTexture;
        Bitmap shipTexture;

        List<List<object>> tableData = new List<List<object>> { };

        #endregion

        #endregion

        public Main()
        {
            InitializeComponent();
            InitializeResources();
            deltaTimeAccumulator = 0;
            studTaskForces = new List<ITaskForce>(5);
            exTaskForces = new List<ITaskForce>(5);
            rng = new Random(42);

            // nothing selected, disable controls
            numShipsSelector.Enabled = false;
            flockRadiusSelector.Enabled = false;
            colorButton.Enabled = false;
            alignmentWeightSelector.Enabled = false;
            cohesionWeightSelector.Enabled = false;
            separationWeightSelector.Enabled = false;

            Console.WriteLine("Task Force Average Position (X, Y)\r");
            Console.WriteLine(new string('=', 63));
            Console.WriteLine("| No.  |      Student AI      |    Instructor AI     | Match? |\r");
            Console.WriteLine(new string('=', 63));

            tableData.Add(new List<object> { "No.", "Student AI", "Intructor AI", "Match" });
        }

        private void InitializeResources()
        {
            backgroundTexture = new Bitmap("ApplicationPresentation/spacefield.png");
            shipTexture = new Bitmap("ApplicationPresentation/ship.png");
            backbuffer = new Bitmap(renderControl.Width, renderControl.Height, PixelFormat.Format32bppArgb);
            backbufferGraphics = Graphics.FromImage(backbuffer);
            renderControlGraphics = renderControl.CreateGraphics();
        }

        public void Render()
        {
            lock (this)
            {
                backbufferGraphics.ResetTransform();
                backbufferGraphics.DrawImageUnscaled(backgroundTexture, Point.Empty);

                foreach (ITaskForce tf in studTaskForces)
                {
                    float[][] matrix = {   new float[] {tf.Color.R / 255f, 0, 0, 0, 0},
                                               new float[] {0, tf.Color.G / 255f, 0, 0, 0},
                                               new float[] {0, 0, tf.Color.B / 255f, 0, 0},
                                               new float[] {0, 0, 0, 1, 0},
                                               new float[] {0, 0, 0, 0, 1}};
                    ColorMatrix modulation = new ColorMatrix(matrix);
                    ImageAttributes imgAtt = new ImageAttributes();
                    imgAtt.SetColorMatrix(modulation);
                    foreach (MovingObject ship in tf.Boids)
                    {
                        // set up matricies to determine where to render
                        backbufferGraphics.ResetTransform();

                        //graphics.TranslateTransform(shipTexture.Width >> 1, shipTexture.Height >> 1, System.Drawing.Drawing2D.MatrixOrder.Append);

                        // setup rotation matrix and
                        backbufferGraphics.RotateTransform((ship.Heading) * 180f / Convert.ToSingle(Math.PI), System.Drawing.Drawing2D.MatrixOrder.Append);

                        // setup translate matrix and
                        // apply translation to transform
                        backbufferGraphics.TranslateTransform(ship.Position.X, ship.Position.Y, System.Drawing.Drawing2D.MatrixOrder.Append);
                        //graphics.DrawImageUnscaledAndClipped(shipTexture, new Rectangle(new Point(20,20), shipTexture.Size));

                        backbufferGraphics.DrawImage(shipTexture, new Rectangle(-shipTexture.Width >> 1, -shipTexture.Height >> 1, shipTexture.Width, shipTexture.Height),
                            0, 0, shipTexture.Width, shipTexture.Height, GraphicsUnit.Pixel, imgAtt);
                    }
                }

                //present the backbuffer
                renderControlGraphics.DrawImageUnscaled(backbuffer, Point.Empty);

            }

            // increment the frame counter for FPS display
            ++frameCount;
        }

        private void UpdateTaskForces()
        {
            // Let's not try to update if Main hasn't finished initializing
            if (null == studTaskForces)
                return;

            shipCount = 0;

            // update all objects
            foreach (ITaskForce tf in studTaskForces)
            {
                lock (this)
                {
                    shipCount += tf.Boids.Count;

                    // perform steering updates (flocking)
                    tf.Update(UpdateTimeStep);

                    // bounds check
                    foreach (MovingObject ship in tf.Boids)
                    {
                        Vector3 position = ship.Position;
                        if (position.X + ship.CollisionRadius < 0)
                            position.X = renderControl.Width + ship.CollisionRadius;
                        if (position.X - ship.CollisionRadius > renderControl.Width)
                            position.X = -ship.CollisionRadius;
                        if (position.Y + ship.CollisionRadius < 0)
                            position.Y = renderControl.Height + ship.CollisionRadius;
                        if (position.Y - ship.CollisionRadius > renderControl.Height)
                            position.Y = -ship.CollisionRadius;
                        ship.Position = position;
                    }

                    totalShipsInfo.Text = "Total Ships: " + shipCount.ToString();
                }
            }

            // update all example objects
            foreach (ITaskForce tf in exTaskForces)
            {
                lock (this)
                {
                    shipCount += tf.Boids.Count;

                    // perform steering updates (flocking)
                    tf.Update(UpdateTimeStep);

                    // bounds check
                    foreach (MovingObject ship in tf.Boids)
                    {
                        Vector3 position = ship.Position;
                        if (position.X + ship.CollisionRadius < 0)
                            position.X = renderControl.Width + ship.CollisionRadius;
                        if (position.X - ship.CollisionRadius > renderControl.Width)
                            position.X = -ship.CollisionRadius;
                        if (position.Y + ship.CollisionRadius < 0)
                            position.Y = renderControl.Height + ship.CollisionRadius;
                        if (position.Y - ship.CollisionRadius > renderControl.Height)
                            position.Y = -ship.CollisionRadius;
                        ship.Position = position;
                    }
                }
            }
        }

        private void updateTimer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            if (false == updateTimer.Enabled)
                return;
            float deltaTime = Convert.ToSingle(updateTimer.Interval) / 1000.0f; // Update calls "should" always be 100Hz
            deltaTimeAccumulator += deltaTime;
            oneSecondAccumulator += deltaTime;
            if (deltaTimeAccumulator > UpdateTimeStep)
            {
                // update accumulator and prevent multiple update calls
                deltaTimeAccumulator -= UpdateTimeStep;
                if (deltaTimeAccumulator > UpdateTimeStep)
                    deltaTimeAccumulator = 0;

                UpdateTaskForces();

            }
            if (oneSecondAccumulator >= 1.0f)
            {
                oneSecondAccumulator = 0;
                lock (this)
                {
                    FPSInfo.Text = "FPS: " + frameCount.ToString();
                    frameCount = 0;
                    if (shipCount > 0)
                    {
                        string no = (taskForceSelector.SelectedIndex + 1).ToString();
                        string studAi = "(" + studTaskForces[taskForceSelector.SelectedIndex].AveragePosition.X.ToString("n3") + ", " + studTaskForces[taskForceSelector.SelectedIndex].AveragePosition.Y.ToString("n3") + ")";
                        string exAi = "(" + exTaskForces[taskForceSelector.SelectedIndex].AveragePosition.X.ToString("n3") + ", " + exTaskForces[taskForceSelector.SelectedIndex].AveragePosition.Y.ToString("n3") + ")";
                        string match = (Math.Abs(exTaskForces[taskForceSelector.SelectedIndex].AveragePosition.X - studTaskForces[taskForceSelector.SelectedIndex].AveragePosition.X) < 0.01 && Math.Abs(exTaskForces[taskForceSelector.SelectedIndex].AveragePosition.Y - studTaskForces[taskForceSelector.SelectedIndex].AveragePosition.Y) < 0.01) ? "True" : "False";

                        tableData[0] = new List<object> { no, studAi, exAi, match};
                        ConsoleTableBuilder
                            .From(tableData)
                            .WithMinLength(new Dictionary<int, int> {
                                { 0, 4 },
                                { 1, 20 },
                                { 2, 20 },
                                { 3, 6 },
                            })
                            .WithCharMapDefinition(new Dictionary<CharMapPositions, char> {
                                {CharMapPositions.BottomLeft, '+' },
                                {CharMapPositions.BottomCenter, '+' },
                                {CharMapPositions.BottomRight, '+' },
                                {CharMapPositions.BorderBottom, '-' },
                                {CharMapPositions.BorderLeft, '|' },
                                {CharMapPositions.BorderRight, '|' },
                                {CharMapPositions.DividerY, '|' },
                            })
                            .ExportAndWriteLine();
                    }
                }
            }
        }

        private void addTaskForceButton_Click(object sender, EventArgs e)
        {
            lock (this)
            {
                ITaskForce tfEx, tfStud;
                tfEx = new ExampleTaskForce();
                tfStud = new TaskForce();

                double num1, num2;
                num1 = rng.NextDouble();
                num2 = rng.NextDouble();

                tfEx.AveragePosition = new Vector3(Convert.ToSingle(
                    num1 * renderControl.Width), Convert.ToSingle(
                    num2 * renderControl.Height), 0);
                tfEx.SetShipAmount(5);
                exTaskForces.Add(tfEx);

                tfStud.AveragePosition = new Vector3(Convert.ToSingle(
                    num1 * renderControl.Width), Convert.ToSingle(
                    num2 * renderControl.Height), 0);
                tfStud.SetShipAmount(5);
                studTaskForces.Add(tfStud);
                taskForceSelector.Items.Add(tfStud.ToString());
                taskForceSelector.SelectedIndex = taskForceSelector.Items.Count - 1;
            }
        }

        private void removeTaskForceButton_Click(object sender, EventArgs e)
        {
            lock (this)
            {
                int index = taskForceSelector.SelectedIndex;
                if (index >= 0)
                {
                    taskForceSelector.Items.RemoveAt(index);
                    studTaskForces[index].RemoveAllShips();
                    studTaskForces.RemoveAt(index);
                    
                    if (0 != studTaskForces.Count)
                    {
                        if (index > studTaskForces.Count - 1)
                            index = studTaskForces.Count - 1;
                        taskForceSelector.SelectedIndex = index;;
                    }
                    else taskForceSelector.SelectedIndex = -1;

                    // remove the task force from the list, based on removed student task force
                    exTaskForces[index].RemoveAllShips();
                    exTaskForces.RemoveAt(index);
                    if (0 != exTaskForces.Count)
                    {
                        if (index > exTaskForces.Count - 1)
                            index = exTaskForces.Count - 1;
                        taskForceSelector.SelectedIndex = index;
                    }
                    else taskForceSelector.SelectedIndex = -1;
                }
            }
        }

        private void numShipsSelector_ValueChanged(object sender, EventArgs e)
        {
            ITaskForce studTf = studTaskForces[taskForceSelector.SelectedIndex];
            lock (this)
            {
                studTf.SetShipAmount(Convert.ToInt32(numShipsSelector.Value));
                taskForceSelector.Items[taskForceSelector.SelectedIndex] = studTf.ToString();

                // update example task force count, based on the student task force count
                if (exTaskForces[taskForceSelector.SelectedIndex] != null && exTaskForces[taskForceSelector.SelectedIndex].Boids.Count != studTaskForces[taskForceSelector.SelectedIndex].Boids.Count)
                {
                    ITaskForce exTf = exTaskForces[taskForceSelector.SelectedIndex];
                    exTf.SetShipAmount(Convert.ToInt32(numShipsSelector.Value));
                }
            }
        }

        private void colorButton_Click(object sender, EventArgs e)
        {
            ITaskForce tf = studTaskForces[taskForceSelector.SelectedIndex];
            ColorDialog cd = new ColorDialog();
            lock (this)
            {
                renderControl.Enabled = false;
                cd.ShowDialog(this);
                tf.Color = cd.Color;
                renderControl.Enabled = true;
            }
            taskForceSelector.Items[taskForceSelector.SelectedIndex] = tf.ToString();
            colorButton.BackColor = cd.Color;
            colorButton.ForeColor = GetReadableForeColor(colorButton.BackColor);
        }

        private void alignmentWeightSelector_ValueChanged(object sender, EventArgs e)
        {
            lock (this)
            {
                ITaskForce tf = studTaskForces[taskForceSelector.SelectedIndex];
                tf.AlignmentStrength = Convert.ToSingle(alignmentWeightSelector.Value)
                    / sliderPrecision;
                alignmentWeightInfo.Text = tf.AlignmentStrength.ToString("F");

                // update example task force alignment strength
                ITaskForce exTf = exTaskForces[taskForceSelector.SelectedIndex];
                exTf.AlignmentStrength = Convert.ToSingle(alignmentWeightSelector.Value)
                    / sliderPrecision;
            }
        }

        private void cohesionWeightSelector_ValueChanged(object sender, EventArgs e)
        {
            lock (this)
            {
                ITaskForce tf = studTaskForces[taskForceSelector.SelectedIndex];
                tf.CohesionStrength = Convert.ToSingle(cohesionWeightSelector.Value)
                    / sliderPrecision;
                cohesionWeightInfo.Text = tf.CohesionStrength.ToString("F");

                // update example task force cohesion strength
                ITaskForce exTf = exTaskForces[taskForceSelector.SelectedIndex];
                exTf.CohesionStrength = Convert.ToSingle(cohesionWeightSelector.Value)
                    / sliderPrecision;
            }
        }

        private void separationWeightSelector_ValueChanged(object sender, EventArgs e)
        {
            lock (this)
            {
                ITaskForce tf = studTaskForces[taskForceSelector.SelectedIndex];
                tf.SeparationStrength = Convert.ToSingle(separationWeightSelector.Value)
                    / sliderPrecision;
                separationWeightInfo.Text = tf.SeparationStrength.ToString("F");

                // update example task force separation strength
                ITaskForce exTf = exTaskForces[taskForceSelector.SelectedIndex];
                exTf.SeparationStrength = Convert.ToSingle(separationWeightSelector.Value)
                    / sliderPrecision;
            }
        }

        private void flockRadiusSelector_ValueChanged(object sender, EventArgs e)
        {
            lock (this)
            {
                ITaskForce tf = studTaskForces[taskForceSelector.SelectedIndex];
                tf.FlockRadius = Convert.ToSingle(flockRadiusSelector.Value);

                // update example task force flock radius
                ITaskForce exTf = exTaskForces[taskForceSelector.SelectedIndex];
                exTf.FlockRadius = Convert.ToSingle(flockRadiusSelector.Value);
            }
        }

        private Color GetReadableForeColor(Color backColor)
        {
            if (backColor.GetBrightness() > 0.5f)
                return Color.Black;
            return Color.White;
        }

        private void Main_FormClosing(object sender, FormClosingEventArgs e)
        {
            updateTimer.Enabled = false;
        }

        private void taskForceSelector_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (-1 == taskForceSelector.SelectedIndex)
            {
                // nothing selected, disable controls
                numShipsSelector.Enabled = false;
                colorButton.Enabled = false;
                alignmentWeightSelector.Enabled = false;
                cohesionWeightSelector.Enabled = false;
                separationWeightSelector.Enabled = false;
                flockRadiusSelector.Enabled = false;
            }
            else
            {
                lock (this)
                {
                    // reset controls to selected taskforce's information
                    ITaskForce tf = studTaskForces[taskForceSelector.SelectedIndex];
                    numShipsSelector.Enabled = true;
                    numShipsSelector.Value = tf.Boids.Count;
                    colorButton.Enabled = true;
                    colorButton.BackColor = Color.FromArgb(tf.Color.ToArgb());
                    colorButton.ForeColor = GetReadableForeColor(colorButton.BackColor);
                    alignmentWeightSelector.Enabled = true;
                    alignmentWeightSelector.Value = Clamp(Convert.ToInt32(tf.AlignmentStrength * sliderPrecision), alignmentWeightSelector.Minimum, alignmentWeightSelector.Maximum);
                    alignmentWeightInfo.Text = tf.AlignmentStrength.ToString("F");
                    cohesionWeightSelector.Enabled = true;
                    cohesionWeightSelector.Value = Clamp(Convert.ToInt32(tf.CohesionStrength * sliderPrecision), cohesionWeightSelector.Minimum, cohesionWeightSelector.Maximum);
                    cohesionWeightInfo.Text = tf.CohesionStrength.ToString("F");
                    separationWeightSelector.Enabled = true;
                    separationWeightSelector.Value = Clamp(Convert.ToInt32(tf.SeparationStrength * sliderPrecision), separationWeightSelector.Minimum, separationWeightSelector.Maximum);
                    separationWeightInfo.Text = tf.SeparationStrength.ToString("F");
                    flockRadiusSelector.Enabled = true;
                    flockRadiusSelector.Value = Clamp(Convert.ToDecimal(tf.FlockRadius), flockRadiusSelector.Minimum, flockRadiusSelector.Maximum);
                }
            }
        }

        private T Clamp<T>(T value, T min, T max) where T : System.IComparable<T>
        {
            return (value.CompareTo(min) < 0) ? min : (value.CompareTo(max) > 0) ? max : value;
        }

    }
}
